<?php
    $con = mysqli_connect("localhost","root","root","nanshan");
    if(!$con){
        echo "connect false";
        exit(0);
    }


?>