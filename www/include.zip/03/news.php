<?php
echo "This is news";
?>