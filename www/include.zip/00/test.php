<?php
echo "The page is test.php"

?>