<meta charset="utf-8"></meta>
<?php 
include('array.php');
$arr = array("小明","小强"," 小丽")；
PrintArr($arr);

?>